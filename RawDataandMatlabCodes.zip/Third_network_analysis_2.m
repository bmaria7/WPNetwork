clear; clc; close all;

%% =========================================================
% PART 3 - MUNICIPAL NETWORK USING MST CONNECTIVITY THRESHOLD
% Robust version for Mainland, Madeira and Azores
%% =========================================================

file = 'RawData_clean.xlsx';
sheetName = 'Treatment';
selectedYear = 2024;

data = readtable(file, 'Sheet', sheetName);

varsNeeded = {'yearparc', 'municipality', ...
              'latitude', 'longitude', ...
              'quantitybev'};

missingVars = setdiff(varsNeeded, ...
    data.Properties.VariableNames);

if ~isempty(missingVars)
    error('Missing required variables: %s', ...
        strjoin(missingVars, ', '));
end

data = data(:, varsNeeded);

%% =========================================================
% Select year
%% =========================================================

data = data(data.yearparc == selectedYear, :);

%% =========================================================
% Format
%% =========================================================

data.municipality = string(data.municipality);

data.latitude = double(data.latitude);

data.longitude = double(data.longitude);

data.quantitybev = double(data.quantitybev);

%% =========================================================
% Remove invalid observations
%% =========================================================

ok = ...
    ~ismissing(data.municipality) & ...
    ~isnan(data.latitude) & ...
    isfinite(data.latitude) & ...
    ~isnan(data.longitude) & ...
    isfinite(data.longitude) & ...
    ~isnan(data.quantitybev) & ...
    isfinite(data.quantitybev) & ...
    data.quantitybev >= 0;

data = data(ok, :);

%% =========================================================
% Aggregate one observation per municipality
%% =========================================================

[G, muni] = findgroups(data.municipality);

lat = splitapply(@mean_omitnan, ...
    data.latitude, G);

lon = splitapply(@mean_omitnan, ...
    data.longitude, G);

bev = splitapply(@sum, ...
    data.quantitybev, G);

muni = string(muni);

n = numel(muni);

%% =========================================================
% Classify territorial components using coordinates
%% =========================================================
% Mainland: longitude > -12
% Madeira : -20 < longitude <= -12
% Azores  : longitude <= -20
%% =========================================================

territory = strings(n, 1);

territory(lon > -12) = "Mainland";

territory(lon <= -12 & lon > -20) = "Madeira";

territory(lon <= -20) = "Azores";

disp(' ')
disp('Municipalities by territorial component:')

disp(groupsummary(table(territory), ...
    'territory'))

%% =========================================================
% Build robust MST-based filtered network
%% =========================================================

[Dkm, A, W, mstThresholdGlobalKm, ...
 territoryThresholds, Gfiltered] = ...
    buildTerritorialMSTFilteredNetwork( ...
        lat, lon, muni, territory);

fprintf('\n==========================================\n');
fprintf('MST-BASED MUNICIPAL NETWORK\n');
fprintf('==========================================\n');

fprintf('Year = %d\n', selectedYear);

fprintf('Number of municipalities = %d\n', n);

fprintf('Global MST connectivity threshold = %.2f km\n', ...
    mstThresholdGlobalKm);

fprintf('Number of filtered edges = %d\n', ...
    numedges(Gfiltered));

fprintf('Average degree = %.4f\n', ...
    mean(degree(Gfiltered)));

disp(' ')
disp('Territory-specific MST thresholds:')

disp(territoryThresholds)

%% =========================================================
% Network metrics
%% =========================================================

deg = degree(Gfiltered);

%% Weighted degree using inverse distance

weightedDegree = zeros(n, 1);

for i = 1:n

    neighbours = find(A(i, :) > 0);

    if ~isempty(neighbours)

        weightedDegree(i) = ...
            sum(1 ./ Dkm(i, neighbours));

    end
end

%% Centrality metrics

bc = centrality(Gfiltered, ...
    'betweenness', ...
    'Cost', Gfiltered.Edges.Weight);

cc = centrality(Gfiltered, ...
    'closeness', ...
    'Cost', Gfiltered.Edges.Weight);

%% =========================================================
% Centrality table
%% =========================================================

Tcentral = table( ...
    string(Gfiltered.Nodes.Name), ...
    territory, ...
    deg, ...
    weightedDegree, ...
    bc, ...
    cc, ...
    bev, ...
    'VariableNames', { ...
    'Municipality', ...
    'Territory', ...
    'Degree', ...
    'WeightedDegree', ...
    'Betweenness', ...
    'Closeness', ...
    'QuantityBEV'});

Tcentral = sortrows(Tcentral, ...
    'Degree', 'descend');

disp(' ')
disp('TOP 10 MOST CENTRAL MUNICIPALITIES BY DEGREE')

disp(Tcentral(1:min(10, ...
    height(Tcentral)), :))

%% =========================================================
% Node colour and size
%% =========================================================

bev_log = log(bev + 1);

if max(bev_log) > min(bev_log)

    bev_norm = ...
        (bev_log - min(bev_log)) / ...
        (max(bev_log) - min(bev_log));

else

    bev_norm = zeros(size(bev_log));

end

%% =========================================================
% Rebuild complete graph and MST for plotting
%% =========================================================

Gcomplete = graph(Dkm, 'upper');

TmstPlot = minspantree(Gcomplete);

%% =========================================================
% Separate territorial subsets
%% =========================================================

idxMainland = territory == "Mainland";

idxIslands = territory ~= "Mainland";

%% =========================================================
% Plot MST - Mainland
%% =========================================================

Amst = adjacency(TmstPlot);

AmstMainland = Amst(idxMainland, idxMainland);

GmstMainland = graph(AmstMainland);

lonMainland = lon(idxMainland);

latMainland = lat(idxMainland);

bevMainland = bev_norm(idxMainland);

figure('Color', 'w');

pMSTmain = plot(GmstMainland, ...
    'XData', lonMainland, ...
    'YData', latMainland, ...
    'NodeLabel', {});

pMSTmain.NodeCData = bevMainland;

pMSTmain.MarkerSize = ...
    3 + 10 * bevMainland;

pMSTmain.EdgeColor = ...
    [0.2 0.2 0.2];

pMSTmain.LineWidth = 1.0;

colormap(turbo);

cb = colorbar;

cb.Label.String = ...
    'Normalised scale of log(BEV + 1)';

xlabel('Longitude');

ylabel('Latitude');

title('Mainland Portugal Minimum Spanning Tree');

xlim([-9.7 -6.0]);

ylim([36.8 42.2]);

grid on;

exportgraphics(gcf, ...
    'figure_MST_mainland.png', ...
    'Resolution', 300);

%% =========================================================
% Plot MST - Islands
%% =========================================================

AmstIslands = Amst(idxIslands, idxIslands);

GmstIslands = graph(AmstIslands);

lonIslands = lon(idxIslands);

latIslands = lat(idxIslands);

bevIslands = bev_norm(idxIslands);

figure('Color', 'w');

pMSTisl = plot(GmstIslands, ...
    'XData', lonIslands, ...
    'YData', latIslands, ...
    'NodeLabel', {});

pMSTisl.NodeCData = bevIslands;

pMSTisl.MarkerSize = ...
    3 + 10 * bevIslands;

pMSTisl.EdgeColor = ...
    [0.2 0.2 0.2];

pMSTisl.LineWidth = 1.0;

colormap(turbo);

cb = colorbar;

cb.Label.String = ...
    'Normalised scale of log(BEV + 1)';

xlabel('Longitude');

ylabel('Latitude');

title('Madeira and Azores Minimum Spanning Tree');

xlim([-32 -15]);

ylim([32 40]);

grid on;

exportgraphics(gcf, ...
    'figure_MST_islands.png', ...
    'Resolution', 300);

%% =========================================================
% Plot filtered network - Mainland
%% =========================================================

Amainland = A(idxMainland, idxMainland);

Gmainland = graph(Amainland);

figure('Color', 'w');

pMain = plot(Gmainland, ...
    'XData', lonMainland, ...
    'YData', latMainland, ...
    'NodeLabel', {});

pMain.NodeCData = bevMainland;

pMain.MarkerSize = ...
    3 + 10 * bevMainland;

pMain.EdgeColor = ...
    [0.65 0.65 0.65];

pMain.LineWidth = 0.35;

colormap(turbo);

cb = colorbar;

cb.Label.String = ...
    'Normalised scale of log(BEV + 1)';

xlabel('Longitude');

ylabel('Latitude');

title('Filtered Municipal Network - Mainland Portugal');

xlim([-9.7 -6.0]);

ylim([36.8 42.2]);

grid on;

%% Highlight top municipalities

[~, idxTopMain] = maxk( ...
    bev(idxMainland), ...
    min(5, sum(idxMainland)));

hold on;

scatter( ...
    lonMainland(idxTopMain), ...
    latMainland(idxTopMain), ...
    70, ...
    'k', ...
    'filled');

hold off;

exportgraphics(gcf, ...
    'figure_network_mainland.png', ...
    'Resolution', 300);

%% =========================================================
% Plot filtered network - Islands
%% =========================================================

Aislands = A(idxIslands, idxIslands);

Gislands = graph(Aislands);

figure('Color', 'w');

pIslands = plot(Gislands, ...
    'XData', lonIslands, ...
    'YData', latIslands, ...
    'NodeLabel', {});

pIslands.NodeCData = bevIslands;

pIslands.MarkerSize = ...
    3 + 10 * bevIslands;

pIslands.EdgeColor = ...
    [0.65 0.65 0.65];

pIslands.LineWidth = 0.35;

colormap(turbo);

cb = colorbar;

cb.Label.String = ...
    'Normalised scale of log(BEV + 1)';

xlabel('Longitude');

ylabel('Latitude');

title('Filtered Municipal Network - Madeira and Azores');

xlim([-32 -15]);

ylim([32 40]);

grid on;

%% Highlight top municipalities

[~, idxTopIslands] = maxk( ...
    bev(idxIslands), ...
    min(5, sum(idxIslands)));

hold on;

scatter( ...
    lonIslands(idxTopIslands), ...
    latIslands(idxTopIslands), ...
    70, ...
    'k', ...
    'filled');

hold off;

exportgraphics(gcf, ...
    'figure_network_islands.png', ...
    'Resolution', 300);

%% =========================================================
% Export
%% =========================================================

outFile = 'Network_Results.xlsx';

NetworkInfo = table( ...
    selectedYear, ...
    n, ...
    numedges(Gfiltered), ...
    mstThresholdGlobalKm, ...
    mean(deg), ...
    max(deg), ...
    'VariableNames', { ...
    'Year', ...
    'NumberMunicipalities', ...
    'NumberFilteredEdges', ...
    'GlobalMSTThresholdKm', ...
    'AverageDegree', ...
    'MaxDegree'});

writetable(NetworkInfo, ...
    outFile, ...
    'Sheet', 'Network_Info');

writetable(territoryThresholds, ...
    outFile, ...
    'Sheet', 'Territory_Thresholds');

writetable(Tcentral, ...
    outFile, ...
    'Sheet', 'Network_Centrality');

fprintf('\nResults exported to: %s\n', ...
    outFile);

%% =========================================================
% Auxiliary functions
%% =========================================================

function m = mean_omitnan(x)

    m = mean(x, 'omitnan');

end

function [distanceKm, A, W, ...
          mstThresholdGlobalKm, ...
          territoryThresholds, ...
          Gfiltered] = ...
    buildTerritorialMSTFilteredNetwork( ...
        latitude, longitude, ...
        municipalityNames, territory)

    latitude = latitude(:);

    longitude = longitude(:);

    municipalityNames = ...
        string(municipalityNames(:));

    territory = string(territory(:));

    n = numel(latitude);

    if n ~= numel(longitude)

        error(['Latitude and longitude must have ', ...
               'the same number of observations.']);

    end

    if n ~= numel(municipalityNames)

        error(['Municipality names must have ', ...
               'the same number of observations ', ...
               'as coordinates.']);

    end

    if n ~= numel(territory)

        error(['Territory vector must have ', ...
               'the same number of observations ', ...
               'as coordinates.']);

    end

    distanceKm = ...
        haversineDistanceMatrix( ...
            latitude, longitude);

    %% -----------------------------------------------------
    % 1. Global MST
    %% -----------------------------------------------------

    Gcomplete = graph(distanceKm, 'upper');

    TmstGlobal = minspantree(Gcomplete);

    mstThresholdGlobalKm = ...
        max(TmstGlobal.Edges.Weight);

    AmstGlobal = adjacency(TmstGlobal);

    AmstGlobal = ...
        double(AmstGlobal > 0);

    %% -----------------------------------------------------
    % 2. Territory-specific thresholds
    %% -----------------------------------------------------

    uniqueTerritories = unique(territory);

    Aterritorial = zeros(n, n);

    territoryNameOut = ...
        strings(numel(uniqueTerritories), 1);

    thresholdOut = ...
        nan(numel(uniqueTerritories), 1);

    nMunicipalitiesOut = ...
        zeros(numel(uniqueTerritories), 1);

    nEdgesOut = ...
        zeros(numel(uniqueTerritories), 1);

    for g = 1:numel(uniqueTerritories)

        terr = uniqueTerritories(g);

        idx = find(territory == terr);

        territoryNameOut(g) = terr;

        nMunicipalitiesOut(g) = numel(idx);

        if numel(idx) < 2

            thresholdOut(g) = NaN;

            nEdgesOut(g) = 0;

            continue;

        end

        Dsub = distanceKm(idx, idx);

        Gsub = graph(Dsub, 'upper');

        TmstSub = minspantree(Gsub);

        thresholdTerritory = ...
            max(TmstSub.Edges.Weight);

        thresholdOut(g) = thresholdTerritory;

        Asub = double( ...
            Dsub <= thresholdTerritory & ...
            Dsub > 0);

        Asub = double((Asub + Asub') > 0);

        Aterritorial(idx, idx) = Asub;

        nEdgesOut(g) = ...
            nnz(triu(Asub, 1));

    end

    territoryThresholds = table( ...
        territoryNameOut, ...
        nMunicipalitiesOut, ...
        thresholdOut, ...
        nEdgesOut, ...
        'VariableNames', { ...
        'Territory', ...
        'NumberMunicipalities', ...
        'MSTThresholdKm', ...
        'NumberEdges'});

    %% -----------------------------------------------------
    % 3. Final network
    %% -----------------------------------------------------

    A = double( ...
        (Aterritorial + AmstGlobal) > 0);

    A = double((A + A') > 0);

    %% -----------------------------------------------------
    % 4. Row-normalised spatial weights
    %% -----------------------------------------------------

    rowSums = sum(A, 2);

    if any(rowSums == 0)

        warning(['At least one municipality ', ...
                 'has zero neighbours after filtering.']);

        rowSums(rowSums == 0) = 1;

    end

    W = A ./ rowSums;

    %% -----------------------------------------------------
    % 5. Build filtered weighted graph
    %% -----------------------------------------------------

    [s, t] = find(triu(A, 1));

    weights = distanceKm( ...
        sub2ind(size(distanceKm), s, t));

    Gfiltered = graph( ...
        s, t, weights, municipalityNames);

end

function D = haversineDistanceMatrix( ...
    latitude, longitude)

    R = 6371;

    latitude = latitude(:);

    longitude = longitude(:);

    n = numel(latitude);

    D = zeros(n, n);

    latRad = deg2rad(latitude);

    lonRad = deg2rad(longitude);

    for i = 1:n

        for j = i+1:n

            dLat = latRad(j) - latRad(i);

            dLon = lonRad(j) - lonRad(i);

            a = ...
                sin(dLat / 2)^2 + ...
                cos(latRad(i)) * ...
                cos(latRad(j)) * ...
                sin(dLon / 2)^2;

            c = 2 * atan2( ...
                sqrt(a), ...
                sqrt(1 - a));

            dij = R * c;

            D(i, j) = dij;

            D(j, i) = dij;

        end
    end
end