clear; clc; close all;

%% =========================================================
% PART 3 - MUNICIPAL NETWORK USING MST CONNECTIVITY THRESHOLD
% Robust version for Mainland, Madeira and Azores
%% =========================================================

file = 'RawData_clean.xlsx';
sheetName = 'Treatment';
selectedYear = 2024;

data = readtable(file, 'Sheet', sheetName);

varsNeeded = {'yearparc', 'municipality', 'latitude', 'longitude', 'quantitybev'};

missingVars = setdiff(varsNeeded, data.Properties.VariableNames);
if ~isempty(missingVars)
    error('Missing required variables: %s', strjoin(missingVars, ', '));
end

data = data(:, varsNeeded);

% Select year
data = data(data.yearparc == selectedYear, :);

% Format
data.municipality = string(data.municipality);
data.latitude = double(data.latitude);
data.longitude = double(data.longitude);
data.quantitybev = double(data.quantitybev);

% Remove invalid observations
ok = ...
    ~ismissing(data.municipality) & ...
    ~isnan(data.latitude) & isfinite(data.latitude) & ...
    ~isnan(data.longitude) & isfinite(data.longitude) & ...
    ~isnan(data.quantitybev) & isfinite(data.quantitybev) & ...
    data.quantitybev >= 0;

data = data(ok, :);

% Aggregate one observation per municipality
[G, muni] = findgroups(data.municipality);

lat = splitapply(@mean_omitnan, data.latitude, G);
lon = splitapply(@mean_omitnan, data.longitude, G);
bev = splitapply(@sum, data.quantitybev, G);

muni = string(muni);
n = numel(muni);

%% =========================================================
% Classify territorial components using coordinates
%% =========================================================
% Approximate rule:
% Mainland: longitude greater than -12
% Madeira: longitude between -20 and -12
% Azores: longitude lower than -20

territory = strings(n, 1);

territory(lon > -12) = "Mainland";
territory(lon <= -12 & lon > -20) = "Madeira";
territory(lon <= -20) = "Azores";

disp(' ')
disp('Municipalities by territorial component:')
disp(groupsummary(table(territory), 'territory'))

%% =========================================================
% Build robust MST-based filtered network
%% =========================================================

[Dkm, A, W, mstThresholdGlobalKm, territoryThresholds, Gfiltered] = ...
    buildTerritorialMSTFilteredNetwork(lat, lon, muni, territory);

fprintf('\n==========================================\n');
fprintf('MST-BASED MUNICIPAL NETWORK\n');
fprintf('==========================================\n');
fprintf('Year = %d\n', selectedYear);
fprintf('Number of municipalities = %d\n', n);
fprintf('Global MST connectivity threshold = %.2f km\n', mstThresholdGlobalKm);
fprintf('Number of filtered edges = %d\n', numedges(Gfiltered));
fprintf('Average degree = %.4f\n', mean(degree(Gfiltered)));

disp(' ')
disp('Territory-specific MST thresholds:')
disp(territoryThresholds)

%% =========================================================
% Network metrics
%% =========================================================

deg = degree(Gfiltered);

% Weighted degree using inverse distance
weightedDegree = zeros(n, 1);

for i = 1:n
    neighbours = find(A(i, :) > 0);

    if ~isempty(neighbours)
        weightedDegree(i) = sum(1 ./ Dkm(i, neighbours));
    end
end

bc = centrality(Gfiltered, 'betweenness', 'Cost', Gfiltered.Edges.Weight);
cc = centrality(Gfiltered, 'closeness', 'Cost', Gfiltered.Edges.Weight);

Tcentral = table( ...
    string(Gfiltered.Nodes.Name), ...
    territory, ...
    deg, ...
    weightedDegree, ...
    bc, ...
    cc, ...
    bev, ...
    'VariableNames', { ...
        'Municipality', 'Territory', 'Degree', 'WeightedDegree', ...
        'Betweenness', 'Closeness', 'QuantityBEV'});

Tcentral = sortrows(Tcentral, 'Degree', 'descend');

disp(' ')
disp('TOP 10 MOST CENTRAL MUNICIPALITIES BY DEGREE')
disp(Tcentral(1:min(10, height(Tcentral)), :))

%% =========================================================
% Node colour and size
%% =========================================================

bev_log = log(bev + 1);

if max(bev_log) > min(bev_log)
    bev_norm = (bev_log - min(bev_log)) / (max(bev_log) - min(bev_log));
else
    bev_norm = zeros(size(bev_log));
end

%% =========================================================
% Plot Global MST
%% =========================================================

% Rebuild complete graph
Gcomplete = graph(Dkm, 'upper');

% Compute MST
TmstPlot = minspantree(Gcomplete);

figure('Color', 'w');

pMST = plot(TmstPlot, ...
    'XData', lon, ...
    'YData', lat, ...
    'NodeLabel', {});

% Node colour based on BEV
pMST.NodeCData = bev_norm;

% Node size
pMST.MarkerSize = 3 + 10 * bev_norm;

% Edge style
pMST.EdgeColor = [0.2 0.2 0.2];
pMST.LineWidth = 1.0;

% Colormap
colormap(turbo);

cb = colorbar;
cb.Label.String = 'Normalised scale of log(BEV + 1)';

xlabel('Longitude');
ylabel('Latitude');

title('Global Minimum Spanning Tree (MST) of Portuguese Municipalities');

grid on;

exportgraphics(gcf, 'figure_MST.png', 'Resolution', 300);

%% =========================================================
% Plot network
%% =========================================================

figure('Color', 'w');

p = plot(Gfiltered, ...
    'XData', lon, ...
    'YData', lat, ...
    'NodeLabel', {});

p.NodeCData = bev_norm;
p.MarkerSize = 3 + 10 * bev_norm;
p.EdgeColor = [0.65 0.65 0.65];
p.LineWidth = 0.35;
p.EdgeAlpha = 0.25;

colormap(turbo);
cb = colorbar;
cb.Label.String = 'Normalised scale of log(BEV + 1)';

xlabel('Longitude');
ylabel('Latitude');
title('Filtered municipal network coloured by log(BEV + 1)');
grid on;

% Highlight top 5 municipalities by BEV using scatter
[~, idxTop] = maxk(bev, min(5, numel(bev)));

hold on;
scatter(lon(idxTop), lat(idxTop), 70, 'k', 'filled');
hold off;

disp(' ')
disp('TOP 5 MUNICIPALITIES BY QUANTITYBEV')
TopBEV = table( ...
    string(muni(idxTop)), ...
    territory(idxTop), ...
    bev(idxTop), ...
    'VariableNames', {'Municipality', 'Territory', 'QuantityBEV'});

disp(TopBEV)

exportgraphics(gcf, 'figure4_1.png', 'Resolution', 300);

%% =========================================================
% Export
%% =========================================================

outFile = 'Network_Results.xlsx';

NetworkInfo = table( ...
    selectedYear, ...
    n, ...
    numedges(Gfiltered), ...
    mstThresholdGlobalKm, ...
    mean(deg), ...
    max(deg), ...
    'VariableNames', { ...
        'Year', 'NumberMunicipalities', 'NumberFilteredEdges', ...
        'GlobalMSTThresholdKm', 'AverageDegree', 'MaxDegree'});

writetable(NetworkInfo, outFile, 'Sheet', 'Network_Info');
writetable(territoryThresholds, outFile, 'Sheet', 'Territory_Thresholds');
writetable(Tcentral, outFile, 'Sheet', 'Network_Centrality');

fprintf('\nResults exported to: %s\n', outFile);

%% =========================================================
% Auxiliary functions
%% =========================================================

function m = mean_omitnan(x)
    m = mean(x, 'omitnan');
end

function [distanceKm, A, W, mstThresholdGlobalKm, territoryThresholds, Gfiltered] = ...
    buildTerritorialMSTFilteredNetwork(latitude, longitude, municipalityNames, territory)

    latitude = latitude(:);
    longitude = longitude(:);
    municipalityNames = string(municipalityNames(:));
    territory = string(territory(:));

    n = numel(latitude);

    if n ~= numel(longitude)
        error('Latitude and longitude must have the same number of observations.');
    end

    if n ~= numel(municipalityNames)
        error('Municipality names must have the same number of observations as coordinates.');
    end

    if n ~= numel(territory)
        error('Territory vector must have the same number of observations as coordinates.');
    end

    distanceKm = haversineDistanceMatrix(latitude, longitude);

    %% -----------------------------------------------------
    % 1. Global MST to guarantee full national connectivity
    %% -----------------------------------------------------

    Gcomplete = graph(distanceKm, 'upper');
    TmstGlobal = minspantree(Gcomplete);

    mstThresholdGlobalKm = max(TmstGlobal.Edges.Weight);

    AmstGlobal = adjacency(TmstGlobal);
    AmstGlobal = double(AmstGlobal > 0);

    %% -----------------------------------------------------
    % 2. Territory-specific thresholds
    %% -----------------------------------------------------

    uniqueTerritories = unique(territory);
    Aterritorial = zeros(n, n);

    territoryNameOut = strings(numel(uniqueTerritories), 1);
    thresholdOut = nan(numel(uniqueTerritories), 1);
    nMunicipalitiesOut = zeros(numel(uniqueTerritories), 1);
    nEdgesOut = zeros(numel(uniqueTerritories), 1);

    for g = 1:numel(uniqueTerritories)

        terr = uniqueTerritories(g);
        idx = find(territory == terr);

        territoryNameOut(g) = terr;
        nMunicipalitiesOut(g) = numel(idx);

        if numel(idx) < 2
            thresholdOut(g) = NaN;
            nEdgesOut(g) = 0;
            continue;
        end

        Dsub = distanceKm(idx, idx);

        Gsub = graph(Dsub, 'upper');
        TmstSub = minspantree(Gsub);

        thresholdTerritory = max(TmstSub.Edges.Weight);
        thresholdOut(g) = thresholdTerritory;

        Asub = double(Dsub <= thresholdTerritory & Dsub > 0);
        Asub = double((Asub + Asub') > 0);

        Aterritorial(idx, idx) = Asub;

        nEdgesOut(g) = nnz(triu(Asub, 1));
    end

    territoryThresholds = table( ...
        territoryNameOut, ...
        nMunicipalitiesOut, ...
        thresholdOut, ...
        nEdgesOut, ...
        'VariableNames', { ...
            'Territory', 'NumberMunicipalities', ...
            'MSTThresholdKm', 'NumberEdges'});

    %% -----------------------------------------------------
    % 3. Final network
    % Territory-filtered edges + global MST bridge edges
    %% -----------------------------------------------------

    A = double((Aterritorial + AmstGlobal) > 0);
    A = double((A + A') > 0);

    %% -----------------------------------------------------
    % 4. Row-normalised spatial weights
    %% -----------------------------------------------------

    rowSums = sum(A, 2);

    if any(rowSums == 0)
        warning('At least one municipality has zero neighbours after filtering.');
        rowSums(rowSums == 0) = 1;
    end

    W = A ./ rowSums;

    %% -----------------------------------------------------
    % 5. Build filtered weighted graph
    %% -----------------------------------------------------

    [s, t] = find(triu(A, 1));
    weights = distanceKm(sub2ind(size(distanceKm), s, t));

    Gfiltered = graph(s, t, weights, municipalityNames);
end

function D = haversineDistanceMatrix(latitude, longitude)

    R = 6371; % Mean Earth radius in kilometres

    latitude = latitude(:);
    longitude = longitude(:);

    n = numel(latitude);
    D = zeros(n, n);

    latRad = deg2rad(latitude);
    lonRad = deg2rad(longitude);

    for i = 1:n
        for j = i+1:n

            dLat = latRad(j) - latRad(i);
            dLon = lonRad(j) - lonRad(i);

            a = sin(dLat / 2)^2 + ...
                cos(latRad(i)) * cos(latRad(j)) * sin(dLon / 2)^2;

            c = 2 * atan2(sqrt(a), sqrt(1 - a));

            dij = R * c;

            D(i, j) = dij;
            D(j, i) = dij;
        end
    end
end