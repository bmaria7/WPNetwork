clear; clc; close all;

%% =========================================================
% PART 1 - LOG-LINEAR MODEL
% Benchmark and extended network specification
%% =========================================================

file = 'RawData_clean.xlsx';
sheetName = 'Treatment';
selectedYear = 2024;

data = readtable(file, 'Sheet', sheetName);

varsNeeded = { ...
    'yearparc', ...
    'municipality', ...
    'quantitybev', ...
    'population', ...
    'density', ...
    'chargingstations', ...
    'LocalParkingIncentive_it', ...
    'latitude', ...
    'longitude'};

missingVars = setdiff(varsNeeded, data.Properties.VariableNames);
if ~isempty(missingVars)
    error('Missing required variables: %s', strjoin(missingVars, ', '));
end

data = data(:, varsNeeded);

% Select year
data = data(data.yearparc == selectedYear, :);

% Convert types
data.municipality = string(data.municipality);
data.quantitybev = double(data.quantitybev);
data.population = double(data.population);
data.density = double(data.density);
data.chargingstations = double(data.chargingstations);
data.LocalParkingIncentive_it = double(data.LocalParkingIncentive_it);
data.latitude = double(data.latitude);
data.longitude = double(data.longitude);

% Missing local incentives are treated as zero
data.LocalParkingIncentive_it(isnan(data.LocalParkingIncentive_it)) = 0;

% Remove invalid observations
ok = ...
    ~ismissing(data.municipality) & ...
    ~isnan(data.quantitybev) & isfinite(data.quantitybev) & data.quantitybev >= 0 & ...
    ~isnan(data.population) & isfinite(data.population) & data.population > 0 & ...
    ~isnan(data.density) & isfinite(data.density) & data.density > 0 & ...
    ~isnan(data.chargingstations) & isfinite(data.chargingstations) & data.chargingstations >= 0 & ...
    ~isnan(data.latitude) & isfinite(data.latitude) & ...
    ~isnan(data.longitude) & isfinite(data.longitude);

data = data(ok, :);

% Aggregate one observation per municipality
[G, muni] = findgroups(data.municipality);

quantitybev = splitapply(@sum, data.quantitybev, G);
population = splitapply(@mean_omitnan, data.population, G);
density = splitapply(@mean_omitnan, data.density, G);
chargingstations = splitapply(@mean_omitnan, data.chargingstations, G);
localParkingRaw = splitapply(@max, data.LocalParkingIncentive_it, G);
latitude = splitapply(@mean_omitnan, data.latitude, G);
longitude = splitapply(@mean_omitnan, data.longitude, G);

T = table( ...
    muni, quantitybev, population, density, chargingstations, ...
    localParkingRaw, latitude, longitude, ...
    'VariableNames', { ...
        'Municipality', 'QuantityBEV', 'Population', 'Density', ...
        'ChargingStations', 'LocalParkingIncentive', 'Latitude', 'Longitude'});

% Local incentive as binary variable
T.LocalIncentive = double(T.LocalParkingIncentive > 0);

%% =========================================================
% Build MST-based filtered network
%% =========================================================

[distanceKm, A, W, mstThresholdKm] = buildMSTFilteredNetwork(T.Latitude, T.Longitude);

fprintf('\nMST connectivity threshold: %.2f km\n', mstThresholdKm);
fprintf('Number of filtered edges: %d\n', nnz(triu(A, 1)));

% Degree centrality
Degree = sum(A, 2);
DegreeNorm = normalize01(Degree);

% Spatial exposure to local incentives
SpatialIncentive = W * T.LocalIncentive;

T.Degree = Degree;
T.DegreeNorm = DegreeNorm;
T.SpatialIncentive = SpatialIncentive;

%% =========================================================
% Construct variables
%% =========================================================

y = log(T.QuantityBEV + 1);

X_pop = log(T.Population);
X_density = log(T.Density);
X_charging = log(T.ChargingStations + 1);
X_local = T.LocalIncentive;
X_spatial = T.SpatialIncentive;
X_centrality = T.DegreeNorm;

%% =========================================================
% Benchmark model
%% =========================================================

X_benchmark = [ ...
    ones(height(T), 1), ...
    X_pop, ...
    X_density, ...
    X_charging];

beta_benchmark = X_benchmark \ y;
yhat_benchmark = X_benchmark * beta_benchmark;

res_benchmark = y - yhat_benchmark;
SSE_benchmark = sum(res_benchmark.^2);
SST = sum((y - mean(y)).^2);
R2_benchmark = 1 - SSE_benchmark / SST;

fprintf('\n======================================\n');
fprintf('BENCHMARK LOG-LINEAR MODEL\n');
fprintf('======================================\n');
fprintf('Dependent variable: log(BEV + 1)\n');
fprintf('N = %d\n', height(T));
fprintf('R2 = %.4f\n', R2_benchmark);
fprintf('\nEstimated equation:\n');
fprintf('log(BEV+1) = %.4f + %.4f log(population) + %.4f log(density) + %.4f log(chargingstations+1)\n', ...
    beta_benchmark(1), beta_benchmark(2), beta_benchmark(3), beta_benchmark(4));

BenchmarkResults = table( ...
    ["Intercept"; "log_population"; "log_density"; "log_chargingstations_plus_1"], ...
    beta_benchmark, ...
    'VariableNames', {'Variable', 'Coefficient'});

disp(BenchmarkResults);

%% =========================================================
% Extended model with incentives and network variables
%% =========================================================

X_extended = [ ...
    ones(height(T), 1), ...
    X_pop, ...
    X_density, ...
    X_charging, ...
    X_local, ...
    X_spatial, ...
    X_centrality];

beta_extended = X_extended \ y;
yhat_extended = X_extended * beta_extended;

res_extended = y - yhat_extended;
SSE_extended = sum(res_extended.^2);
R2_extended = 1 - SSE_extended / SST;

fprintf('\n======================================\n');
fprintf('EXTENDED LOG-LINEAR MODEL\n');
fprintf('======================================\n');
fprintf('Dependent variable: log(BEV + 1)\n');
fprintf('N = %d\n', height(T));
fprintf('R2 = %.4f\n', R2_extended);
fprintf('\nEstimated equation:\n');
fprintf(['log(BEV+1) = %.4f + %.4f log(population) + %.4f log(density) + ' ...
         '%.4f log(chargingstations+1) + %.4f LocalIncentive + %.4f SpatialIncentive + %.4f DegreeCentrality\n'], ...
    beta_extended(1), beta_extended(2), beta_extended(3), beta_extended(4), ...
    beta_extended(5), beta_extended(6), beta_extended(7));

ExtendedResults = table( ...
    ["Intercept"; "log_population"; "log_density"; "log_chargingstations_plus_1"; ...
     "LocalIncentive"; "SpatialIncentive"; "DegreeCentrality"], ...
    beta_extended, ...
    'VariableNames', {'Variable', 'Coefficient'});

disp(ExtendedResults);

%% =========================================================
% Export regression tables
%% =========================================================

outFile = 'Network_Results.xlsx';

if isfile(outFile)
    delete(outFile);
end

writetable(BenchmarkResults, outFile, 'Sheet', 'LogLinear_Benchmark');
writetable(ExtendedResults, outFile, 'Sheet', 'LogLinear_Extended');
writetable(T, outFile, 'Sheet', 'Municipality_Data');

NetworkInfo = table( ...
    height(T), ...
    nnz(triu(A, 1)), ...
    mstThresholdKm, ...
    'VariableNames', {'NumberMunicipalities', 'NumberFilteredEdges', 'MSTThresholdKm'});

writetable(NetworkInfo, outFile, 'Sheet', 'Network_Info');

%% =========================================================
% Figure 1
%% =========================================================

figure('Color', 'w');
scatter(log(T.Population), y, 26, 'o', 'filled', ...
    'MarkerFaceAlpha', 0.55, ...
    'MarkerEdgeAlpha', 0.55);
xlabel('log(population)');
ylabel('log(BEV + 1)');
title('Log-log relationship between population and BEVs');
grid on;

exportgraphics(gcf, 'figure1_1.png', 'Resolution', 300);

%% =========================================================
% Auxiliary functions
%% =========================================================

function m = mean_omitnan(x)
    m = mean(x, 'omitnan');
end

function xnorm = normalize01(x)

    xmin = min(x, [], 'omitnan');
    xmax = max(x, [], 'omitnan');

    if isempty(xmin) || isempty(xmax) || isnan(xmin) || isnan(xmax) || xmax == xmin
        xnorm = zeros(size(x));
    else
        xnorm = (x - xmin) ./ (xmax - xmin);
    end
end

function [distanceKm, A, W, mstThresholdKm] = buildMSTFilteredNetwork(latitude, longitude)

    latitude = latitude(:);
    longitude = longitude(:);

    distanceKm = haversineDistanceMatrix(latitude, longitude);

    Gcomplete = graph(distanceKm, 'upper');
    Tmst = minspantree(Gcomplete);

    mstThresholdKm = max(Tmst.Edges.Weight);

    A = double(distanceKm <= mstThresholdKm & distanceKm > 0);
    A = double((A + A') > 0);

    rowSums = sum(A, 2);

    if any(rowSums == 0)
        warning('At least one municipality has zero neighbours after filtering.');
        rowSums(rowSums == 0) = 1;
    end

    W = A ./ rowSums;
end

function D = haversineDistanceMatrix(latitude, longitude)

    R = 6371;

    latitude = latitude(:);
    longitude = longitude(:);

    n = numel(latitude);
    D = zeros(n, n);

    latRad = deg2rad(latitude);
    lonRad = deg2rad(longitude);

    for i = 1:n
        for j = i+1:n

            dLat = latRad(j) - latRad(i);
            dLon = lonRad(j) - lonRad(i);

            a = sin(dLat / 2)^2 + ...
                cos(latRad(i)) * cos(latRad(j)) * sin(dLon / 2)^2;

            c = 2 * atan2(sqrt(a), sqrt(1 - a));

            dij = R * c;

            D(i, j) = dij;
            D(j, i) = dij;
        end
    end
end