clear; clc; close all;
set(groot, 'defaultAxesToolbarVisible', 'off');

%% =========================================================
% PART 2 - RANK-SIZE DISTRIBUTION AND POWER-LAW BEHAVIOUR
%% =========================================================

file = 'RawData_clean.xlsx';
sheetName = 'Treatment';
selectedYear = 2024;

data = readtable(file, 'Sheet', sheetName);

varsNeeded = {'yearparc', 'municipality', 'quantitybev'};

missingVars = setdiff(varsNeeded, data.Properties.VariableNames);
if ~isempty(missingVars)
    error('Missing required variables: %s', strjoin(missingVars, ', '));
end

data = data(:, varsNeeded);

% Select year
data = data(data.yearparc == selectedYear, :);

% Format
data.municipality = string(data.municipality);
data.quantitybev = double(data.quantitybev);

% Remove invalid observations
ok = ...
    ~ismissing(data.municipality) & ...
    ~isnan(data.quantitybev) & ...
    isfinite(data.quantitybev) & ...
    data.quantitybev >= 0;

data = data(ok, :);

% Aggregate one observation per municipality
[G, muni] = findgroups(data.municipality);
bev_muni = splitapply(@sum, data.quantitybev, G);

T = table(muni, bev_muni, 'VariableNames', {'Municipality', 'QuantityBEV'});
T = sortrows(T, 'QuantityBEV', 'descend');

% Rank
n = height(T);
rankBEV = (1:n)';

% Logs
log_rank = log(rankBEV);
log_size = log(T.QuantityBEV + 1);

% Rank-size regression
X = [ones(n, 1), log_rank];
beta = X \ log_size;

alpha = beta(1);
slope = beta(2);
b = -slope;
a = exp(alpha);

% Fitted values
log_size_hat = X * beta;
size_hat = exp(log_size_hat) - 1;

% R-squared
SSE = sum((log_size - log_size_hat).^2);
SST = sum((log_size - mean(log_size)).^2);
R2 = 1 - SSE / SST;

% Results
disp('======================================')
disp('RANK-SIZE POWER LAW OF BEVs')
disp('======================================')
fprintf('Year = %d\n', selectedYear);
fprintf('Number of municipalities = %d\n', n);
fprintf('alpha = %.4f\n', alpha);
fprintf('slope = %.4f\n', slope);
fprintf('a = %.4f\n', a);
fprintf('b = %.4f\n', b);
fprintf('R2 = %.4f\n', R2);

fprintf('\nEquation in logs:\n');
fprintf('log(BEV + 1) = %.4f %.4f*log(rank)\n', alpha, slope);

fprintf('\nApproximate equation in levels:\n');
fprintf('BEV + 1 = %.4f / rank^(%.4f)\n', a, b);

% Top 10
k = min(10, n);

Top10 = table( ...
    rankBEV(1:k), ...
    T.Municipality(1:k), ...
    T.QuantityBEV(1:k), ...
    'VariableNames', {'Rank', 'Municipality', 'QuantityBEV'});

disp(' ')
disp('Top 10 municipalities by BEVs')
disp(Top10)

% Export results
outFile = 'Network_Results.xlsx';

RankSizeResults = table( ...
    selectedYear, n, alpha, slope, a, b, R2, ...
    'VariableNames', {'Year', 'N', 'Alpha', 'Slope', 'A', 'B', 'R2'});

writetable(RankSizeResults, outFile, 'Sheet', 'RankSize_Results');
writetable(T, outFile, 'Sheet', 'RankSize_Data');

%% =========================================================
% Figure 2 - standard rank-size plot
%% =========================================================

figure('Color', 'w');
scatter(rankBEV, T.QuantityBEV, 26, 'o', 'filled', ...
    'MarkerFaceAlpha', 0.55, ...
    'MarkerEdgeAlpha', 0.55);
hold on;
plot(rankBEV, size_hat, 'LineWidth', 1.6);
xlabel('Rank');
ylabel('Quantity BEV');
title('Rank-size distribution of BEVs in Portugal');
grid on;
hold off;

exportgraphics(gcf, 'figure2_1.png', 'Resolution', 300);

%% =========================================================
% Figure 3 - log-log power-law plot
%% =========================================================

figure('Color', 'w');

scatter(log_rank, log_size, 26, 'o', 'filled', ...
    'MarkerFaceAlpha', 0.55, ...
    'MarkerEdgeAlpha', 0.55);

hold on;

plot(log_rank, log_size_hat, 'LineWidth', 1.6);

xlabel('log(rank)');
ylabel('log(BEV + 1)');
title('Power-law behaviour of BEVs in Portugal');

grid on;
box on;

ax = gca;
if isprop(ax, 'Toolbar')
    ax.Toolbar.Visible = 'off';
end

hold off;

exportgraphics(gcf, 'figure3_1.png', 'Resolution', 300);