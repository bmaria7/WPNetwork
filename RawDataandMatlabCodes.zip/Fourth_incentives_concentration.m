clear; clc; close all;

%% =========================================================
% PART 4 - RANK-SIZE COMPARISON BY LOCAL INCENTIVES
%% =========================================================

file = 'RawData_clean.xlsx';
sheetName = 'Treatment';
selectedYear = 2024;

data = readtable(file, 'Sheet', sheetName);

varsNeeded = { ...
    'yearparc', ...
    'municipality', ...
    'quantitybev', ...
    'fiscalincentives_pervehicle', ...
    'LocalParkingIncentive_it'};

missingVars = setdiff(varsNeeded, data.Properties.VariableNames);
if ~isempty(missingVars)
    error('Missing required variables: %s', strjoin(missingVars, ', '));
end

data = data(:, varsNeeded);

% Select year
data = data(data.yearparc == selectedYear, :);

% Format
data.municipality = string(data.municipality);
data.quantitybev = double(data.quantitybev);
data.fiscalincentives_pervehicle = double(data.fiscalincentives_pervehicle);
data.LocalParkingIncentive_it = double(data.LocalParkingIncentive_it);

% Missing local incentives are treated as zero
data.LocalParkingIncentive_it(isnan(data.LocalParkingIncentive_it)) = 0;

% Remove invalid observations
ok = ...
    ~ismissing(data.municipality) & ...
    ~isnan(data.quantitybev) & isfinite(data.quantitybev) & data.quantitybev >= 0 & ...
    ~isnan(data.fiscalincentives_pervehicle) & isfinite(data.fiscalincentives_pervehicle) & ...
    ~isnan(data.LocalParkingIncentive_it) & isfinite(data.LocalParkingIncentive_it);

data = data(ok, :);

% Aggregate one observation per municipality
[G, muni] = findgroups(data.municipality);

bev_muni = splitapply(@sum, data.quantitybev, G);
fiscal_muni = splitapply(@mean_omitnan, data.fiscalincentives_pervehicle, G);
local_muni = splitapply(@max, data.LocalParkingIncentive_it, G);

Tmuni = table( ...
    muni, ...
    bev_muni, ...
    fiscal_muni, ...
    local_muni, ...
    'VariableNames', { ...
        'Municipality', 'QuantityBEV', ...
        'FiscalIncentive', 'LocalParkingIncentive'});

Tmuni.LocalIncentive = double(Tmuni.LocalParkingIncentive > 0);

% Create groups
data_local = Tmuni(Tmuni.LocalIncentive == 1, :);
data_nolocal = Tmuni(Tmuni.LocalIncentive == 0, :);

% Rank-size by group
[b_local, R2_local, T_local, rank_local, log_rank_local, log_size_local, log_hat_local] = ...
    make_rank_size(data_local);

[b_nolocal, R2_nolocal, T_nolocal, rank_nolocal, log_rank_nolocal, log_size_nolocal, log_hat_nolocal] = ...
    make_rank_size(data_nolocal);

%% =========================================================
% Display results
%% =========================================================

disp('==========================================')
disp('RANK-SIZE COMPARISON OF BEVs')
disp('==========================================')
fprintf('Year = %d\n', selectedYear);
fprintf('With local incentive: b = %.4f | R2 = %.4f | N = %d\n', ...
    b_local, R2_local, height(T_local));
fprintf('Without local incentive: b = %.4f | R2 = %.4f | N = %d\n', ...
    b_nolocal, R2_nolocal, height(T_nolocal));

disp(' ')
disp('Note: this comparison is descriptive and should not be interpreted as causal evidence.')

%% =========================================================
% Figure 5
%% =========================================================

figure('Color', 'w');
hold on;

legendEntries = {};

if ~isempty(T_local)
    scatter(log_rank_local, log_size_local, 28, 'o', 'filled', ...
        'MarkerFaceAlpha', 0.55, ...
        'MarkerEdgeAlpha', 0.55);
    legendEntries{end+1} = 'With local incentive';

    plot(log_rank_local, log_hat_local, 'LineWidth', 1.6);
    legendEntries{end+1} = 'Local fit';
end

if ~isempty(T_nolocal)
    scatter(log_rank_nolocal, log_size_nolocal, 28, 's', 'filled', ...
        'MarkerFaceAlpha', 0.55, ...
        'MarkerEdgeAlpha', 0.55);
    legendEntries{end+1} = 'Without local incentive';

    plot(log_rank_nolocal, log_hat_nolocal, 'LineWidth', 1.6);
    legendEntries{end+1} = 'No-local fit';
end

xlabel('log(rank)');
ylabel('log(BEV + 1)');
title('Rank-size comparison of BEVs: with and without local incentive');

if ~isempty(legendEntries)
    legend(legendEntries, 'Location', 'best');
end

grid on;
hold off;

exportgraphics(gcf, 'figure5_1.png', 'Resolution', 300);

%% =========================================================
% Top 10 tables
%% =========================================================

k1 = min(10, height(T_local));
k2 = min(10, height(T_nolocal));

disp(' ')
disp('Top 10 - municipalities with local incentive')
if k1 > 0
    disp(T_local(1:k1, :))
else
    disp('No municipalities with local incentive.')
end

disp(' ')
disp('Top 10 - municipalities without local incentive')
if k2 > 0
    disp(T_nolocal(1:k2, :))
else
    disp('No municipalities without local incentive.')
end

%% =========================================================
% Export
%% =========================================================

outFile = 'Network_Results.xlsx';

ComparisonResults = table( ...
    ["With local incentive"; "Without local incentive"], ...
    [height(T_local); height(T_nolocal)], ...
    [b_local; b_nolocal], ...
    [R2_local; R2_nolocal], ...
    'VariableNames', {'Group', 'N', 'PowerLawExponent_b', 'R2'});

writetable(ComparisonResults, outFile, 'Sheet', 'LocalIncentive_Comparison');
writetable(Tmuni, outFile, 'Sheet', 'LocalIncentive_Data');
writetable(T_local, outFile, 'Sheet', 'RankSize_Local');
writetable(T_nolocal, outFile, 'Sheet', 'RankSize_NoLocal');

fprintf('\nResults exported to: %s\n', outFile);

%% =========================================================
% Auxiliary functions
%% =========================================================

function m = mean_omitnan(x)
    m = mean(x, 'omitnan');
end

function [b, R2, T, rankBEV, log_rank, log_size, log_hat] = make_rank_size(data_group)

    if isempty(data_group)
        b = NaN;
        R2 = NaN;
        T = data_group;
        rankBEV = [];
        log_rank = [];
        log_size = [];
        log_hat = [];
        return;
    end

    T = data_group(:, {'Municipality', 'QuantityBEV'});
    T = sortrows(T, 'QuantityBEV', 'descend');

    rankBEV = (1:height(T))';

    log_rank = log(rankBEV);
    log_size = log(T.QuantityBEV + 1);

    if height(T) < 2 || std(log_size, 'omitnan') == 0
        b = NaN;
        R2 = NaN;
        log_hat = log_size;
        return;
    end

    X = [ones(height(T), 1), log_rank];
    beta = X \ log_size;

    log_hat = X * beta;

    SSE = sum((log_size - log_hat).^2);
    SST = sum((log_size - mean(log_size)).^2);

    if SST == 0
        R2 = NaN;
    else
        R2 = 1 - SSE / SST;
    end

    b = -beta(2);
end