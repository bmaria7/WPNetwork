Please follow the steps below to run the .m code:

1. Run FirstStep_ABM_Calibrated_V11_4;
2. Run SecondStep_runPolicyScenarios.