% =========================================================
% ABM + POLICY SIMULATION LABORATORY
% =========================================================

clear; clc; close all;

%% =========================================================
% PARAMETERS
%% =========================================================

rng('default');
rng(123,'twister');

fileName  = 'RawData_clean.xlsx';
sheetName = 'Treatment';

nAgents          = 1000;
nSelectedPerYear = 50;
nRep             = 500;

trainYears = [2021 2022 2023];
testYears  = [2024];

featureNames = {'Social','Spatial','Redistribution','Parking','Matthew','Income'};

specMatrix = dec2bin(0:(2^numel(featureNames)-1)) - '0';
specList   = cell(size(specMatrix,1),1);

for k = 1:size(specMatrix,1)
    active = featureNames(logical(specMatrix(k,:)));
    if isempty(active)
        specList{k} = 'Baseline';
    else
        specList{k} = strjoin(active,'_');
    end
end

%% =========================================================
% MODEL PARAMETERS
%% =========================================================

P.threshold           = 1.80;
P.thetaRedistribution = 1;
P.sigmaEndowment      = 0.15;
P.sigmaShock          = 0.25;
P.maxAdoptionRate     = 0.35;
P.slopeLogit          = 3.00;

P.rDEN     = 0.20;
P.sigmaDEN = 0.10;

P.useDensity  = true;
P.useStations = true;

%% =========================================================
% READ DATA
%% =========================================================

T = readtable(fileName,'Sheet',sheetName);
D = buildModelData(T,nAgents);

P.KDEN = prctile(D.charging_density(:),95);

%% =========================================================
% BASELINE SCENARIO
%% =========================================================

BaseScenario = makePolicySpec('Spatial_Matthew_Income',1.00,0.00,[]);

%% =========================================================
% CONVERGENCE TEST
%% =========================================================

repGrid = [10 25 50 100 250 500];
RMSE    = zeros(size(repGrid));

for i = 1:numel(repGrid)
    fprintf('Testing %d replications...\n',repGrid(i));
    Avg = simulateABMAverage(D,P,nSelectedPerYear,repGrid(i),BaseScenario);
    fit = computeFitStatsSubset(Avg,testYears);
    RMSE(i) = fit.RMSE;
end

figure('Color','w');
plot(repGrid,RMSE,'-o','LineWidth',2);
xlabel('Number of replications'); ylabel('RMSE');
title('Monte Carlo convergence'); grid on;
exportgraphics(gcf,'figure3_monte_carlo_convergence.png','Resolution',300);

%% =========================================================
% RUN ALL SPECIFICATIONS (historic fit)
%% =========================================================

AllFit  = table();
Results = struct();

for s = 1:numel(specList)

    currentSpec = specList{s};
    fprintf('\n====================================\n');
    fprintf('SPECIFICATION: %s\n', upper(currentSpec));
    fprintf('====================================\n');

    Scenario = makePolicySpec(currentSpec,1.00,0.00,[]);
    Avg = simulateABMAverage(D,P,nSelectedPerYear,nRep,Scenario);

    fitTrain = computeFitStatsSubset(Avg,trainYears);
    fitTest  = computeFitStatsSubset(Avg,testYears);

    tempFit = table( ...
        string(currentSpec), ...
        fitTrain.RMSE, fitTrain.MAE, fitTrain.Corr, ...
        fitTest.RMSE,  fitTest.MAE,  fitTest.Corr, ...
        (0.4*fitTest.Corr - 0.3*fitTest.RMSE - 0.3*fitTest.MAE), ...
        'VariableNames',{'Specification','TrainRMSE','TrainMAE','TrainCorr', ...
                         'TestRMSE','TestMAE','TestCorr','Score'});

    AllFit = [AllFit; tempFit];
    Results.(currentSpec) = Avg;
end

AllFit = sortrows(AllFit,'Score','descend');
disp(AllFit);

FullModel    = "Social_Spatial_Redistribution_Parking_Matthew_Income";
Best3        = string(AllFit.Specification(1:3));
ModelsToPlot = ["Baseline"; "Matthew"; FullModel; Best3];

%% =========================================================
% FIGURE 1
%% =========================================================

figure('Color','w'); hold on;
for s = 1:numel(ModelsToPlot)
    spec  = char(ModelsToPlot(s));
    Tab   = Results.(spec);
    years = unique(Tab.Year);
    annual = zeros(numel(years),1);
    for i = 1:numel(years)
        annual(i) = sum(Tab.AdoptedAgentsThisYear(Tab.Year==years(i)));
    end
    plot(years,annual,'LineWidth',2);
end
xlabel('Year'); ylabel('Average simulated annual adoptions');
lgd = legend(ModelsToPlot,'Location','eastoutside','NumColumns',1);
lgd.Box='off'; grid on;
exportgraphics(gcf,'figure1_top10_models.png','Resolution',300);

%% =========================================================
% FIGURE 2
%% =========================================================

figure('Color','w');
tiledlayout(2,3,'Padding','compact');
for s = 1:numel(ModelsToPlot)
    spec     = char(ModelsToPlot(s));
    nexttile;
    Tab      = Results.(spec);
    lastYear = max(Tab.Year);
    Last     = Tab(Tab.Year==lastYear,:);
    scatter(Last.ObservedBEVShare,Last.SimulatedBEVShare,25,'filled'); hold on;
    maxVal = max([Last.ObservedBEVShare; Last.SimulatedBEVShare]);
    plot([0 maxVal],[0 maxVal],'--k');
    title(spec,'Interpreter','none');
    xlabel('Observed'); ylabel('Simulated'); grid on;
end
exportgraphics(gcf,'figure2_top6_models.png','Resolution',300);

%% =========================================================
% POLICY SCENARIOS 2025-2026
%% =========================================================

FutureYears = [2025 2026];
BestSpec    = char(AllFit.Specification(1));
fprintf('\nBest specification used for forecasts: %s\n',BestSpec);

ScenarioA = makePolicySpec(BestSpec,1.00,0.15,FutureYears);
ScenarioB = makePolicySpec(BestSpec,1.00,1.00,FutureYears);
ScenarioC = makePolicySpec(BestSpec,2.00,0.15,FutureYears);

fprintf('\n--- Running Scenario A (Status Quo) ---\n');
AvgA = simulateABMAverage(D,P,nSelectedPerYear,nRep,ScenarioA);

fprintf('\n--- Running Scenario B (Expansion) ---\n');
AvgB = simulateABMAverage(D,P,nSelectedPerYear,nRep,ScenarioB);

fprintf('\n--- Running Scenario C (Higher Incentives) ---\n');
AvgC = simulateABMAverage(D,P,nSelectedPerYear,nRep,ScenarioC);

fprintf('\n');
fprintf('Total adoptions 2026\n');
fprintf('A = %.0f\n', sum(AvgA.AdoptedAgentsThisYear(AvgA.Year==2026)));
fprintf('B = %.0f\n', sum(AvgB.AdoptedAgentsThisYear(AvgB.Year==2026)));
fprintf('C = %.0f\n', sum(AvgC.AdoptedAgentsThisYear(AvgC.Year==2026)));

fprintf('\nBest model = %s\n',BestSpec);
fprintf('Redistribution active? %d\n', contains(BestSpec,'Redistribution'));

%novos prints
fprintf('\nRelative change vs Status Quo\n');

fprintf('Infrastructure: %+0.1f%%\n', ...
100*(sum(AvgB.AdoptedAgentsThisYear(AvgB.Year==2026)) - ...
     sum(AvgA.AdoptedAgentsThisYear(AvgA.Year==2026))) / ...
     sum(AvgA.AdoptedAgentsThisYear(AvgA.Year==2026)));

fprintf('Incentives: %+0.1f%%\n', ...
100*(sum(AvgC.AdoptedAgentsThisYear(AvgC.Year==2026)) - ...
     sum(AvgA.AdoptedAgentsThisYear(AvgA.Year==2026))) / ...
     sum(AvgA.AdoptedAgentsThisYear(AvgA.Year==2026)));

%% =========================================================
% FIGURE 3 - TOTAL BEV TRAJECTORIES
%% =========================================================

totalA = arrayfun(@(y) sum(AvgA.AdoptedAgentsThisYear(AvgA.Year==y)),FutureYears);
totalB = arrayfun(@(y) sum(AvgB.AdoptedAgentsThisYear(AvgB.Year==y)),FutureYears);
totalC = arrayfun(@(y) sum(AvgC.AdoptedAgentsThisYear(AvgC.Year==y)),FutureYears);

figure('Color','w'); hold on;
plot(FutureYears,totalA,'-o','LineWidth',2);
plot(FutureYears,totalB,'-s','LineWidth',2);
plot(FutureYears,totalC,'-d','LineWidth',2);
xlabel('Year'); ylabel('Total new BEV adoptions (mean across reps)');
title('Policy scenarios — 2025–2026');
legend({'Status Quo (A)','Infrastructure Expansion (B)','Higher Incentives (C)'}, ...
       'Location','best'); grid on;
exportgraphics(gcf,'figure4_policy_scenarios.png','Resolution',300);

%% =========================================================
% FIGURE 4 - MUNICIPALITY BAR MAPS
%% =========================================================

for yIdx = 1:numel(FutureYears)

    y = FutureYears(yIdx);

    shareA = AvgA.SimulatedBEVShare(AvgA.Year==y);
    shareB = AvgB.SimulatedBEVShare(AvgB.Year==y);
    shareC = AvgC.SimulatedBEVShare(AvgC.Year==y);
    munis  = AvgA.Municipality(AvgA.Year==y);

    [~,ord] = sort(shareA,'descend');
    topN    = min(25,numel(ord));
    idx     = ord(1:topN);

    figure('Color','w','Position',[100 100 1100 600]);
    bar([shareA(idx) shareB(idx) shareC(idx)]);
    set(gca,'XTick',1:topN,'XTickLabel',munis(idx),'XTickLabelRotation',60);

    ylabel('Simulated BEV share');
    title(sprintf('Portugal %d — top %d municipalities by scenario',y,topN));
    legend({'Status Quo','Expansion','Higher Incentives'},'Location','best');
    grid on;

    exportgraphics(gcf,...
        sprintf('figure%d_top25_municipalities_%d.png',4+yIdx,y),...
        'Resolution',300);

end

%% =========================================================
% POLICY DIAGNOSTICS
%% =========================================================

diagnoseConcentration(AvgA,AvgB,AvgC,FutureYears);

%% =========================================================
% LOCAL FUNCTIONS
%% =========================================================

function S = makePolicySpec(features,fiscalMult,infraGrowth,futureYears)
    S.Features             = features;
    S.FiscalMultiplier     = fiscalMult;
    S.InfrastructureGrowth = infraGrowth;
    S.FutureYears          = futureYears;
end

function Avg = simulateABMAverage(D,P,nSelectedPerYear,nRep,Scenario)

    allTables = cell(nRep,1);
    for r = 1:nRep
        allTables{r} = simulateABMOnce(D,P,nSelectedPerYear,r,Scenario);
    end
    Big = vertcat(allTables{:});

    [G,yearG,muniG] = findgroups(Big.Year,Big.Municipality);

    SimulatedBEVShare     = splitapply(@mean,Big.SimulatedBEVShare,G);
    ObservedBEVShare      = splitapply(@mean,Big.ObservedBEVShare,G);
    AdoptedAgentsThisYear = splitapply(@mean,Big.AdoptedAgentsThisYear,G);

    Avg = table(yearG,muniG, ...
        SimulatedBEVShare,ObservedBEVShare,AdoptedAgentsThisYear, ...
        'VariableNames',{'Year','Municipality', ...
                         'SimulatedBEVShare','ObservedBEVShare', ...
                         'AdoptedAgentsThisYear'});

    Avg.MunicipalityShare = zeros(height(Avg),1);
    yrs = unique(Avg.Year);
    for i = 1:numel(yrs)
        mask  = Avg.Year == yrs(i);
        total = sum(Avg.AdoptedAgentsThisYear(mask));
        if total > 0
            Avg.MunicipalityShare(mask) = Avg.AdoptedAgentsThisYear(mask)./total;
        end
    end
end

function MuniYearTable = simulateABMOnce(D,P,nSelectedPerYear,seed,Scenario)

    rng(seed,'twister');

    spec        = Scenario.Features;
    futureYears = Scenario.FutureYears;
    fiscalMult  = Scenario.FiscalMultiplier;
    infraGrowth = Scenario.InfrastructureGrowth;

    nMuni         = D.nMuni;
    agentsPerMuni = D.agentsPerMuni;
    nAgents       = sum(agentsPerMuni);

    Endowment = zeros(nAgents,1);
    HomeMuni  = zeros(nAgents,1);

    row            = 1;
    incomeBaseNorm = normalize01(D.income(:,1));

    for m = 1:nMuni
        nm  = agentsPerMuni(m);
        idx = row:(row+nm-1);
        HomeMuni(idx)  = m;
        Endowment(idx) = 0.5 + 0.5.*incomeBaseNorm(m) + ...
                        P.sigmaEndowment.*randn(nm,1);
        row = row + nm;
    end

    Adopted           = false(nAgents,1);
    cumulativeAdopted = zeros(nMuni,1);
    MuniYearTable     = table();

    allYears = D.years(:)';
    if ~isempty(futureYears)
        allYears = [allYears futureYears(:)'];
    end
    nYearsTotal = numel(allYears);

    DEN_sim = D.charging_density(:,1);
    lastObs = D.nYears;

    for yi = 1:nYearsTotal

        y = allYears(yi);
        isFuture = yi > lastObs;

        if ~isFuture
            income     = normalize01(D.income(:,yi));
            incentive  = normalize01(D.incentive(:,yi));
            parking    = normalize01(D.parking(:,yi));
            bevObs     = normalize01(D.bev_share(:,yi));
            stations   = normalize01(D.chargingstations(:,yi));

            if yi == 1
                DEN_sim = D.charging_density(:,1);
            else
                DEN_sim = DEN_sim + ...
                    P.rDEN.*DEN_sim.*(1 - DEN_sim./P.KDEN) + ...
                    P.sigmaDEN.*DEN_sim.*randn(size(DEN_sim));
                DEN_sim = max(DEN_sim,0);
            end
            observedBEVForReport = D.bev_share(:,yi);
        else
            income    = normalize01(D.income(:,lastObs));
            parking   = normalize01(D.parking(:,lastObs));
            bevObs    = normalize01(D.bev_share(:,lastObs));
            incentive = normalize01(D.incentive(:,lastObs));

            growthSteps = yi - lastObs;
            stationsRaw = D.chargingstations(:,lastObs).*(1+infraGrowth).^growthSteps;
            stations    = normalize01(stationsRaw);

            rDEN_future = P.rDEN.*(1+infraGrowth);

            DEN_sim = DEN_sim + ...
                      rDEN_future.*DEN_sim.*(1 - DEN_sim./P.KDEN) + ...
                      P.sigmaDEN.*DEN_sim.*randn(size(DEN_sim));
            DEN_sim = max(DEN_sim,0);

            observedBEVForReport = nan(nMuni,1);
        end

        chargingDensity = normalize01(DEN_sim);

        infrastructure = zeros(nMuni,1);
        nTerms = 0;
        if P.useDensity
            infrastructure = infrastructure + chargingDensity;
            nTerms = nTerms + 1;
        end
        if P.useStations
            infrastructure = infrastructure + stations;
            nTerms = nTerms + 1;
        end
        if nTerms > 0
            infrastructure = infrastructure ./ nTerms;
        end

        disadvantage       = ((1-income)+(1-bevObs)+(1-chargingDensity))./3;
        effectiveIncentive = fiscalMult .* incentive .* ...
                             (1 + P.thetaRedistribution.*disadvantage);

        simShare    = cumulativeAdopted./max(agentsPerMuni,1);
        networkPeer = D.spatialWeights*simShare;

        eligible   = find(~Adopted);
        nToSelect  = min(nSelectedPerYear,numel(eligible));
        selected   = eligible(randperm(numel(eligible),nToSelect));
        adoptedNow = zeros(nMuni,1);

        useSocial         = contains(spec,'Social','IgnoreCase',true);
        useSpatial        = contains(spec,'Spatial','IgnoreCase',true);
        useRedistribution = contains(spec,'Redistribution','IgnoreCase',true);
        useParking        = contains(spec,'Parking','IgnoreCase',true);
        useMatthew        = contains(spec,'Matthew','IgnoreCase',true);
        useIncome         = contains(spec,'Income','IgnoreCase',true);

        for j = 1:numel(selected)
            a = selected(j);
            m = HomeMuni(a);

            inverseMatthew = (1-Endowment(a)).*(1-simShare(m));
            shock          = randn.*P.sigmaShock;

            payoff = Endowment(a) + ...
                     0.80.*effectiveIncentive(m) + ...
                     0.80.*infrastructure(m) + ...
                     shock;

            if useSocial,  payoff = payoff + 0.50.*simShare(m);    end
            if useSpatial, payoff = payoff + 0.40.*networkPeer(m); end
            if useParking, payoff = payoff + 0.30.*parking(m);     end
            if useMatthew, payoff = payoff + inverseMatthew;       end
            if useIncome,  payoff = payoff + 0.40.*income(m);      end

            prob = 1./(1+exp(-P.slopeLogit.*(payoff-P.threshold)));

            if rand < prob
                Adopted(a)    = true;
                adoptedNow(m) = adoptedNow(m)+1;
            end
        end

        cumulativeAdopted = cumulativeAdopted + adoptedNow;
        simShare = min(cumulativeAdopted./max(agentsPerMuni,1),P.maxAdoptionRate);

        tmp = table(repmat(y,nMuni,1),D.municipalities, ...
            simShare,observedBEVForReport,adoptedNow, ...
            'VariableNames',{'Year','Municipality', ...
                             'SimulatedBEVShare','ObservedBEVShare', ...
                             'AdoptedAgentsThisYear'});

        MuniYearTable = [MuniYearTable; tmp];
    end
end

function stats = computeFitStatsSubset(Tab,yearsSubset)
    idx = ismember(Tab.Year,yearsSubset);
    xs  = Tab.SimulatedBEVShare(idx);
    ys  = Tab.ObservedBEVShare(idx);
    err = xs - ys;
    stats.RMSE = sqrt(mean(err.^2,'omitnan'));
    stats.MAE  = mean(abs(err),'omitnan');
    if std(xs,'omitnan') > 0 && std(ys,'omitnan') > 0
        C = corrcoef(xs,ys,'Rows','complete');
        stats.Corr = C(1,2);
    else
        stats.Corr = NaN;
    end
end

function xnorm = normalize01(x)
    xmin = min(x); xmax = max(x);
    if xmax == xmin
        xnorm = zeros(size(x));
    else
        xnorm = (x - xmin)./(xmax - xmin);
    end
end

function diagnoseConcentration(AvgA,AvgB,AvgC,FutureYears)

    fprintf('\n=========== POLICY DIAGNOSTICS ===========\n');
    scenarios = {'A: Status Quo', AvgA;
                 'B: Expansion',  AvgB;
                 'C: Incentives', AvgC};

    coreMunis = ["Lisboa","Porto","Oeiras","Cascais","Sintra","Loures", ...
                 "Amadora","Almada","Odivelas","Matosinhos", ...
                 "Vila Nova de Gaia","Gondomar","Maia"];

    fprintf('%-15s %-6s %-10s %-12s %-14s %-12s\n', ...
            'Scenario','Year','HHI','CoreShare','InteriorShare','Top10Share');
    fprintf('%s\n',repmat('-',1,75));

    diagRows = {};

    for s = 1:size(scenarios,1)
        name = scenarios{s,1};
        Avg  = scenarios{s,2};

        for yi = 1:numel(FutureYears)
            y     = FutureYears(yi);
            mask  = Avg.Year == y;

            shares = Avg.MunicipalityShare(mask);
            munis  = string(Avg.Municipality(mask));

            HHI           = sum(shares.^2);
            isCore        = ismember(munis,coreMunis);
            coreShare     = sum(shares(isCore));
            interiorShare = 1 - coreShare;

            sortedShares = sort(shares,'descend');
            top10Share   = sum(sortedShares(1:min(10,numel(sortedShares))));

            fprintf('%-15s %-6d %-10.4f %-12.4f %-14.4f %-12.4f\n', ...
                    name,y,HHI,coreShare,interiorShare,top10Share);

            diagRows(end+1,:) = {name,y,HHI,coreShare,interiorShare,top10Share}; %#ok<AGROW>
        end
    end

    DiagTable = cell2table(diagRows, ...
        'VariableNames',{'Scenario','Year','HHI','CoreShare', ...
                         'InteriorShare','Top10Share'});
    writetable(DiagTable,'policy_diagnostics.csv');
    fprintf('\nSaved: policy_diagnostics.csv\n');

    fprintf('\n--- Matthew Effect (HHI change %d -> %d) ---\n', ...
            FutureYears(1),FutureYears(end));
    for s = 1:size(scenarios,1)
        name = scenarios{s,1};
        Avg  = scenarios{s,2};

        sh25 = Avg.MunicipalityShare(Avg.Year == FutureYears(1));
        sh26 = Avg.MunicipalityShare(Avg.Year == FutureYears(end));

        HHI25 = sum(sh25.^2);
        HHI26 = sum(sh26.^2);
        delta = HHI26 - HHI25;

        if delta > 0
            tag = 'concentration INCREASES (Matthew persists)';
        elseif delta < 0
            tag = 'concentration DECREASES (interior catching up)';
        else
            tag = 'stable';
        end

        fprintf('%-15s  dHHI = %+0.4f   -> %s\n',name,delta,tag);
    end

    % --- Visual summary --------------------------------------------------
    figure('Color','w','Position',[100 100 900 450]);
    tiledlayout(1,2,'Padding','compact');

    % HHI bar chart
    nexttile;
    HHIvals = reshape([diagRows{:,3}],numel(FutureYears),size(scenarios,1));
    bar(HHIvals');
    set(gca,'XTickLabel',scenarios(:,1));
    ylabel('HHI of municipality shares');
    title('Spatial concentration of adoption');
    legend(arrayfun(@(y) sprintf('%d',y),FutureYears, ...
                    'UniformOutput',false),'Location','best');
    grid on;

    % Core vs Interior share
    nexttile;
    coreVals = reshape([diagRows{:,4}],numel(FutureYears),size(scenarios,1));
    bar(coreVals');
    set(gca,'XTickLabel',scenarios(:,1));
    ylabel('Lisbon-Porto core share');
    title('Core vs interior balance');
    legend(arrayfun(@(y) sprintf('%d',y),FutureYears, ...
                    'UniformOutput',false),'Location','best');
    grid on;

    exportgraphics(gcf,'figure7_policy_diagnostics.png','Resolution',300);
end

function D = buildModelData(T,nAgents)

    years    = unique(T.yearparc);
    years    = sort(years);
    baseYear = years(1);

    T0 = T(T.yearparc == baseYear,:);
    [~,ia] = unique(T0.municipality,'stable');
    T0 = T0(ia,:);

    municipalities = string(T0.municipality);
    nMuni          = numel(municipalities);

    population       = [];
    income           = [];
    bev_share        = [];
    chargingstations = [];
    charging_density = [];
    incentive        = [];
    parking          = [];

    for y = 1:numel(years)
        Ty = T(T.yearparc == years(y),:);
        [~,ia] = unique(Ty.municipality,'stable');
        Ty = Ty(ia,:);
        [~,loc] = ismember(municipalities,string(Ty.municipality));

        population(:,y)       = Ty.population(loc);
        income(:,y)           = Ty.income(loc);
        bev_share(:,y)        = Ty.bev_share(loc);
        chargingstations(:,y) = Ty.chargingstations(loc);
        charging_density(:,y) = Ty.charging_density(loc);
        incentive(:,y)        = Ty.fiscalincentives_pervehicle(loc);
        parking(:,y)          = Ty.LocalParkingIncentive_it(loc);
    end

    popBase  = population(:,1);
    popShare = popBase ./ sum(popBase);

    agentsPerMuni    = round(nAgents.*popShare);
    diffAgents       = nAgents - sum(agentsPerMuni);
    agentsPerMuni(1) = agentsPerMuni(1) + diffAgents;

    distanceKm = haversineDistanceMatrix(T0.latitude,T0.longitude);

    G         = graph(distanceKm,'upper');
    Tmst      = minspantree(G);
    threshold = max(Tmst.Edges.Weight);

    A       = double(distanceKm <= threshold & distanceKm > 0);
    rowSums = sum(A,2);
    W       = A ./ max(rowSums,1);

    D.years            = years;
    D.nYears           = numel(years);
    D.nMuni            = nMuni;
    D.municipalities   = municipalities;
    D.population       = population;
    D.income           = income;
    D.bev_share        = bev_share;
    D.chargingstations = chargingstations;
    D.charging_density = charging_density;
    D.incentive        = incentive;
    D.parking          = parking;
    D.agentsPerMuni    = agentsPerMuni;
    D.spatialWeights   = W;
end

function D = haversineDistanceMatrix(lat,lon)

    R   = 6371;
    lat = deg2rad(lat);
    lon = deg2rad(lon);
    n   = numel(lat);
    D   = zeros(n);

    for i = 1:n
        for j = i+1:n
            dLat = lat(j)-lat(i);
            dLon = lon(j)-lon(i);

            a = sin(dLat/2)^2 + ...
                cos(lat(i))*cos(lat(j))*sin(dLon/2)^2;
            c = 2*atan2(sqrt(a),sqrt(1-a));
            dij = R*c;

            D(i,j) = dij;
            D(j,i) = dij;
        end
    end
end