% =========================================================
% ABM...
% =========================================================

clear; clc; close all;

%% =========================================================
% PARAMETERS
%% =========================================================

rng('default');
rng(123,'twister');

fileName = 'RawData_clean.xlsx';
sheetName = 'Treatment';

nAgents = 1000;
nSelectedPerYear = 50;

nRep = 500; %number of rep.

trainYears = [2021 2022 2023];
testYears  = [2024];

featureNames = {'Social','Spatial','Redistribution','Parking','Matthew','Income'};

specMatrix = dec2bin(0:(2^numel(featureNames)-1)) - '0';

specList = cell(size(specMatrix,1),1);

for k = 1:size(specMatrix,1)
    active = featureNames(logical(specMatrix(k,:)));
    if isempty(active)
        specList{k} = 'Baseline';
    else
        specList{k} = strjoin(active,'_');
    end
end

%% =========================================================
% MODEL PARAMETERS
%% =========================================================

P.threshold = 1.80;
P.thetaRedistribution = 1;
P.sigmaEndowment = 0.15;
P.sigmaShock = 0.25;
P.maxAdoptionRate = 0.35;
P.slopeLogit = 3.00;

% ---  (SDE) ---
P.rDEN     = 0.20;   % logistic growth rate of charging density

P.sigmaDEN = 0.10;   % volatility of the density process

% --- Infrastructure switches (Section 4.13) ---
P.useDensity  = true;
P.useStations = true;

%% =========================================================
% READ DATA
%% =========================================================

T = readtable(fileName,'Sheet',sheetName);

%% =========================================================
% BUILD MODEL DATA
%% =========================================================

D = buildModelData(T,nAgents);

P.KDEN = prctile(D.charging_density(:),95); % carrying capacity

%% =========================================================
% CONVERGENCE TEST
%% =========================================================

policySpec = 'Spatial_Matthew_Income';

repGrid = [10 25 50 100 250 500];

RMSE = zeros(size(repGrid));

for i = 1:numel(repGrid)

    fprintf('Testing %d replications...\n',repGrid(i));

    Avg = simulateABMAverage( ...
        D,...
        P,...
        nSelectedPerYear,...
        repGrid(i),...
        policySpec);

    fit = computeFitStatsSubset(Avg,testYears);

    RMSE(i) = fit.RMSE;

end

figure('Color','w');

plot(repGrid,RMSE,'-o','LineWidth',2);

xlabel('Number of replications');
ylabel('RMSE');
title('Monte Carlo convergence');
exportgraphics(gcf,'figure3_monte_carlo_convergence.png','Resolution',300);

grid on;

%% =========================================================
% RUN ALL SPECIFICATIONS
%% =========================================================

AllFit = table();

Results = struct();

for s = 1:numel(specList)

    currentSpec = specList{s};

    fprintf('\n====================================\n');
    fprintf('SPECIFICATION: %s\n', upper(currentSpec));
    fprintf('====================================\n');

    Avg = simulateABMAverage( ...
        D, P, nSelectedPerYear, nRep, currentSpec);

    fitTrain = computeFitStatsSubset(Avg, trainYears);
    fitTest  = computeFitStatsSubset(Avg, testYears);

    tempFit = table( ...
        string(currentSpec), ...
        fitTrain.RMSE, ...
        fitTrain.MAE, ...
        fitTrain.Corr, ...
        fitTest.RMSE, ...
        fitTest.MAE, ...
        fitTest.Corr, ...
        (0.4*fitTest.Corr - 0.3*fitTest.RMSE - 0.3*fitTest.MAE), ...
        'VariableNames',{ ...
        'Specification', ...
        'TrainRMSE', ...
        'TrainMAE', ...
        'TrainCorr', ...
        'TestRMSE', ...
        'TestMAE', ...
        'TestCorr','Score'});

    AllFit = [AllFit; tempFit];

    Results.(currentSpec) = Avg;

end

AllFit = sortrows(AllFit,'Score','descend');
disp(AllFit);

FullModel = "Social_Spatial_Redistribution_Parking_Matthew_Income";

Best3 = string(AllFit.Specification(1:3));

ModelsToPlot = [ ...
    "Baseline";
    "Matthew";
    FullModel;
    Best3];

%% =========================================================
% FIGURE 1 - TOP 6 MODELS
%% =========================================================

figure('Color','w');

hold on;

TopModels = ModelsToPlot;

for s = 1:numel(TopModels)

    spec = char(TopModels(s));

    Tab = Results.(spec);

    years = unique(Tab.Year);

    annual = zeros(numel(years),1);

    for i = 1:numel(years)

        annual(i) = sum( ...
            Tab.AdoptedAgentsThisYear( ...
            Tab.Year == years(i)));

    end

    plot(years,annual,'LineWidth',2);

end

xlabel('Year');
ylabel('Average simulated annual adoptions');

lgd = legend(TopModels,...
    'Location','eastoutside',...
    'NumColumns',1);

lgd.Box = 'off';

grid on;

exportgraphics(gcf,...
    'figure1_top10_models.png',...
    'Resolution',300);

%% =========================================================
% FIGURE 2 - TOP 10 MODELS
%% =========================================================

figure('Color','w');

tiledlayout(2,3,'Padding','compact');

TopModels = ModelsToPlot;

for s = 1:numel(TopModels)

    spec = char(TopModels(s));

    nexttile;

    Tab = Results.(spec);

    lastYear = max(Tab.Year);

    Last = Tab(Tab.Year == lastYear,:);

    scatter( ...
        Last.ObservedBEVShare,...
        Last.SimulatedBEVShare,...
        25,'filled');

    hold on;

    maxVal = max([ ...
        Last.ObservedBEVShare;
        Last.SimulatedBEVShare]);

    plot([0 maxVal],[0 maxVal],'--k');

    title(spec,'Interpreter','none');

    xlabel('Observed');
    ylabel('Simulated');

    grid on;

end

exportgraphics(gcf,...
    'figure2_top6_models.png',...
    'Resolution',300);

%% =========================================================
% FUNCTIONS
%% =========================================================

function Avg = simulateABMAverage( ...
    D, P, nSelectedPerYear, nRep, spec)

allTables = cell(nRep,1);

for r = 1:nRep

    tab = simulateABMOnce( ...
        D, P, nSelectedPerYear, r, spec);

    allTables{r} = tab;

end

Big = vertcat(allTables{:});

[G,yearG,muniG] = findgroups( ...
    Big.Year, ...
    Big.Municipality);

SimulatedBEVShare = splitapply( ...
    @mean, Big.SimulatedBEVShare, G);

ObservedBEVShare = splitapply( ...
    @mean, Big.ObservedBEVShare, G);

AdoptedAgentsThisYear = splitapply( ...
    @mean, Big.AdoptedAgentsThisYear, G);

Avg = table( ...
    yearG, muniG, ...
    SimulatedBEVShare, ...
    ObservedBEVShare, ...
    AdoptedAgentsThisYear, ...
    'VariableNames',{ ...
    'Year','Municipality', ...
    'SimulatedBEVShare', ...
    'ObservedBEVShare', ...
    'AdoptedAgentsThisYear'});

end

function MuniYearTable = simulateABMOnce( ...
    D, P, nSelectedPerYear, seed, spec)

rng(seed,'twister');

nMuni = D.nMuni;

agentsPerMuni = D.agentsPerMuni;

nAgents = sum(agentsPerMuni);

Endowment = zeros(nAgents,1);
HomeMuni = zeros(nAgents,1);

row = 1;

incomeBaseNorm = normalize01(D.income(:,1));

for m = 1:nMuni

    nm = agentsPerMuni(m);

    idx = row:(row+nm-1);

    HomeMuni(idx) = m;

    Endowment(idx) = ...
        0.5 + ...
        0.5 .* incomeBaseNorm(m) + ...
        P.sigmaEndowment .* randn(nm,1);

    row = row + nm;

end

Adopted = false(nAgents,1);

cumulativeAdopted = zeros(nMuni,1);

MuniYearTable = table();

% --- pre-load empirical charging density series ---
DEN = D.charging_density;          % full empirical matrix (nMuni x nYears)
DEN_sim = DEN(:,1);                % SDE state initialised at observed t=1

for y = 1:D.nYears

    income     = normalize01(D.income(:,y));
    incentive  = normalize01(D.incentive(:,y));
    parking    = normalize01(D.parking(:,y));
    bevObs     = normalize01(D.bev_share(:,y));
    stations   = normalize01(D.chargingstations(:,y));

    % --- NEW: Euler-Maruyama update of charging density ---
    if y == 1
        DEN_sim = DEN(:,1);
    else
        % dDEN = r*DEN*(1 - DEN/K)*dt + sigma*DEN*dW,  dt = 1 year
        DEN_sim = DEN_sim ...
                + P.rDEN .* DEN_sim .* ...
                  (1 - DEN_sim ./ P.KDEN) ...
                + P.sigmaDEN .* DEN_sim .* randn(size(DEN_sim));

        DEN_sim = max(DEN_sim,0);
    end

    chargingDensity = normalize01(DEN_sim);

    % --- combined infrastructure signal (Section 4.13) ---
    infrastructure = zeros(nMuni,1);
    nTerms = 0;
    if P.useDensity
        infrastructure = infrastructure + chargingDensity;
        nTerms = nTerms + 1;
    end
    if P.useStations
        infrastructure = infrastructure + stations;
        nTerms = nTerms + 1;
    end
    if nTerms > 0
        infrastructure = infrastructure ./ nTerms;
    end

    % --- disadvantage now uses chargingDensity (DEN_{m,t}) ---
    disadvantage = ...
        ((1-income) + ...
         (1-bevObs) + ...
         (1-chargingDensity)) ./ 3;

    effectiveIncentive = ...
        incentive .* ...
        (1 + P.thetaRedistribution .* disadvantage);

    simShare = cumulativeAdopted ./ max(agentsPerMuni,1);

    networkPeer = D.spatialWeights * simShare;

    eligible = find(~Adopted);

    nToSelect = min(nSelectedPerYear,numel(eligible));

    selected = eligible(randperm(numel(eligible),nToSelect));

    adoptedNow = zeros(nMuni,1);

    useSocial         = contains(spec,'Social','IgnoreCase',true);
    useSpatial        = contains(spec,'Spatial','IgnoreCase',true);
    useRedistribution = contains(spec,'Redistribution','IgnoreCase',true);
    useParking        = contains(spec,'Parking','IgnoreCase',true);
    useMatthew        = contains(spec,'Matthew','IgnoreCase',true);
    useIncome         = contains(spec,'Income','IgnoreCase',true);

    for j = 1:numel(selected)

        a = selected(j);

        m = HomeMuni(a);

        inverseMatthew = ...
            (1-Endowment(a)) .* ...
            (1-simShare(m));

        shock = randn .* P.sigmaShock;

        % --- payoff: charging replaced by infrastructure (density + stations) ---
        payoff = Endowment(a) + ...
                 0.80 .* incentive(m) + ...
                 0.80 .* infrastructure(m) + ...
                 shock;

        if useRedistribution
            payoff = payoff + (effectiveIncentive(m)-incentive(m));
        end

        if useSocial
            payoff = payoff + 0.50 .* simShare(m);
        end

        if useSpatial
            payoff = payoff + 0.40 .* networkPeer(m);
        end

        if useParking
            payoff = payoff + 0.30 .* parking(m);
        end

        if useMatthew
            payoff = payoff + inverseMatthew;
        end

        if useIncome
            payoff = payoff + 0.40 .* income(m);
        end

        prob = 1 ./ ...
            (1 + exp( ...
            -P.slopeLogit .* ...
            (payoff - P.threshold)));

        if rand < prob

            Adopted(a) = true;

            adoptedNow(m) = adoptedNow(m) + 1;

        end

    end

    cumulativeAdopted = cumulativeAdopted + adoptedNow;

    simShare = min( ...
        cumulativeAdopted ./ max(agentsPerMuni,1), ...
        P.maxAdoptionRate);

    tmp = table( ...
        repmat(D.years(y),nMuni,1), ...
        D.municipalities, ...
        simShare, ...
        D.bev_share(:,y), ...
        adoptedNow, ...
        'VariableNames',{ ...
        'Year','Municipality', ...
        'SimulatedBEVShare', ...
        'ObservedBEVShare', ...
        'AdoptedAgentsThisYear'});

    MuniYearTable = [MuniYearTable; tmp];

end

end

function stats = computeFitStatsSubset(Tab,yearsSubset)

idx = ismember(Tab.Year,yearsSubset);

xs = Tab.SimulatedBEVShare(idx);
ys = Tab.ObservedBEVShare(idx);

err = xs - ys;

stats.RMSE = sqrt(mean(err.^2,'omitnan'));
stats.MAE  = mean(abs(err),'omitnan');

if std(xs) > 0 && std(ys) > 0
    C = corrcoef(xs,ys);
    stats.Corr = C(1,2);
else
    stats.Corr = NaN;
end

end

function xnorm = normalize01(x)

xmin = min(x);
xmax = max(x);

if xmax == xmin
    xnorm = zeros(size(x));
else
    xnorm = (x - xmin) ./ (xmax - xmin);
end

end

function D = buildModelData(T,nAgents)

years = unique(T.yearparc);
years = sort(years);

baseYear = years(1);

T0 = T(T.yearparc == baseYear,:);

[~,ia] = unique(T0.municipality,'stable');
T0 = T0(ia,:);

municipalities = string(T0.municipality);
nMuni = numel(municipalities);

population = [];
income = [];
bev_share = [];
chargingstations = [];
charging_density = [];
incentive = [];
parking = [];

for y = 1:numel(years)

    Ty = T(T.yearparc == years(y),:);

    [~,ia] = unique(Ty.municipality,'stable');
    Ty = Ty(ia,:);

    [~,loc] = ismember(municipalities,string(Ty.municipality));

    population(:,y)       = Ty.population(loc);
    income(:,y)           = Ty.income(loc);
    bev_share(:,y)        = Ty.bev_share(loc);
    chargingstations(:,y) = Ty.chargingstations(loc);
    charging_density(:,y) = Ty.charging_density(loc);
    incentive(:,y)        = Ty.fiscalincentives_pervehicle(loc);
    parking(:,y)          = Ty.LocalParkingIncentive_it(loc);

end

popBase = population(:,1);
popShare = popBase ./ sum(popBase);

agentsPerMuni = round(nAgents .* popShare);

diffAgents = nAgents - sum(agentsPerMuni);
agentsPerMuni(1) = agentsPerMuni(1) + diffAgents;

distanceKm = haversineDistanceMatrix( ...
    T0.latitude, T0.longitude);

G = graph(distanceKm,'upper');
Tmst = minspantree(G);
threshold = max(Tmst.Edges.Weight);

A = double(distanceKm <= threshold & distanceKm > 0);
rowSums = sum(A,2);
W = A ./ max(rowSums,1);

D.years          = years;
D.nYears         = numel(years);
D.nMuni          = nMuni;
D.municipalities = municipalities;
D.population     = population;
D.income         = income;
D.bev_share      = bev_share;
D.chargingstations = chargingstations;
D.charging_density = charging_density;
D.incentive      = incentive;
D.parking        = parking;
D.agentsPerMuni  = agentsPerMuni;
D.spatialWeights = W;

end

function D = haversineDistanceMatrix(lat,lon)

R = 6371;

lat = deg2rad(lat);
lon = deg2rad(lon);

n = numel(lat);

D = zeros(n);

for i = 1:n
    for j = i+1:n

        dLat = lat(j)-lat(i);
        dLon = lon(j)-lon(i);

        a = sin(dLat/2)^2 + ...
            cos(lat(i))*cos(lat(j))*sin(dLon/2)^2;

        c = 2*atan2(sqrt(a),sqrt(1-a));

        dij = R*c;

        D(i,j) = dij;
        D(j,i) = dij;

    end
end

end